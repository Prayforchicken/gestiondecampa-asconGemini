
import React from 'react';
import { CampaignStatus } from '../../types';

interface IconProps {
  className?: string;
}

export const NotStartedIcon: React.FC<IconProps> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);

export const InProgressIcon: React.FC<IconProps> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 11.667 0l3.181-3.183m-4.991-2.691V5.25A2.25 2.25 0 0 0 16.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v6.75A2.25 2.25 0 0 0 9.75 16.5h3.977a2.25 2.25 0 0 0 2.25-2.25Z" />
  </svg>
);

export const FinishedIcon: React.FC<IconProps> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);

export const getStatusIcon = (status: CampaignStatus): React.ReactNode => {
  switch (status) {
    case CampaignStatus.NOT_STARTED:
      return <NotStartedIcon className="w-5 h-5 text-gray-500" />;
    case CampaignStatus.IN_PROGRESS:
      return <InProgressIcon className="w-5 h-5 text-blue-500" />;
    case CampaignStatus.FINISHED:
      return <FinishedIcon className="w-5 h-5 text-green-500" />;
    default:
      return null;
  }
};

export const getStatusColor = (status: CampaignStatus): string => {
  switch (status) {
    case CampaignStatus.NOT_STARTED:
      return 'bg-gray-200 text-gray-700';
    case CampaignStatus.IN_PROGRESS:
      return 'bg-blue-200 text-blue-700';
    case CampaignStatus.FINISHED:
      return 'bg-green-200 text-green-700';
    default:
      return 'bg-gray-200 text-gray-700';
  }
};
