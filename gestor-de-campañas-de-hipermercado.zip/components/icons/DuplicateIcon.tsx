import React from 'react';

interface IconProps {
  className?: string;
}

export const DuplicateIcon: React.FC<IconProps> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 0 1-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 0 1 1.5.124m7.5 10.376H3.375m0 0h3.375m-3.375 0V11.25m10.5 6L21 12m0 0h-5.625M15 12V6.375c0-.621.504-1.125 1.125-1.125h.375c.621 0 1.125.504 1.125 1.125V12m-2.25 0h4.5" />
  </svg>
);