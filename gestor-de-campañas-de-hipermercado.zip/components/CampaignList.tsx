
import React, { useState } from 'react';
import { Campaign, CampaignStatus, CampaignType } from '../types';
import CampaignCard from './CampaignCard';
import { formatDate } from '../utils';

interface CampaignListProps {
  title: string;
  campaigns: Campaign[];
  onUpdateStatus: (campaignId: string, status: CampaignStatus) => void;
  onToggleTask: (campaignId: string, taskId: string) => void;
  onDeleteCampaign: (campaignId: string) => void;
  onAddTask: (campaignId: string, taskDescription: string) => void;
  onEditCampaign: (campaignId: string) => void;
  onDuplicateCampaign: (campaignId: string) => void;
  titleColorClass?: string;
}

const CampaignList: React.FC<CampaignListProps> = ({ 
  title, 
  campaigns, 
  onUpdateStatus, 
  onToggleTask, 
  onDeleteCampaign, 
  onAddTask, 
  onEditCampaign, 
  onDuplicateCampaign, 
  titleColorClass = 'text-gray-700' 
}) => {
  const [expandedCampaignId, setExpandedCampaignId] = useState<string | null>(null);

  const handleToggleExpand = (campaignId: string) => {
    setExpandedCampaignId(prevId => (prevId === campaignId ? null : campaignId));
  };

  const summaryDateOptions: Intl.DateTimeFormatOptions = { day: '2-digit', month: 'short', year: 'numeric' };

  const getTypeSpecificColors = (type: CampaignType) => {
    if (type === CampaignType.NATIONAL) {
      return {
        bg: 'bg-purple-50',
        hoverBg: 'hover:bg-purple-100',
        nameText: 'text-purple-700',
        dateText: 'text-purple-600',
        progressTrack: 'bg-purple-200',
        progressFill: 'bg-purple-600',
        border: 'border-purple-400',
      };
    }
    // CampaignType.LOCAL
    return {
      bg: 'bg-teal-50',
      hoverBg: 'hover:bg-teal-100',
      nameText: 'text-teal-700',
      dateText: 'text-teal-600',
      progressTrack: 'bg-teal-200',
      progressFill: 'bg-teal-600',
      border: 'border-teal-400',
    };
  };

  return (
    <div className="bg-slate-100 p-3 sm:p-4 rounded-lg shadow-md min-w-[300px] flex-1">
      <h2 className={`text-xl font-bold mb-4 pb-2 border-b-2 ${titleColorClass} border-opacity-60`}>{title} ({campaigns.length})</h2>
      {campaigns.length === 0 ? (
        <p className="text-gray-500 italic text-sm">No hay campañas en esta categoría.</p>
      ) : (
        <div className="space-y-3 sm:space-y-4">
          {campaigns.map(campaign => {
            const completedTasks = campaign.tasks.filter(task => task.completed).length;
            const totalTasks = campaign.tasks.length;
            const progressPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
            const isExpanded = expandedCampaignId === campaign.id;
            const colors = getTypeSpecificColors(campaign.type);

            return (
              <div 
                key={campaign.id} 
                className={`bg-white rounded-lg border-2 ${colors.border} shadow-lg transition-all duration-300 ease-in-out overflow-hidden ${isExpanded ? 'ring-2 ring-primary ring-opacity-50' : ''}`}
              >
                <div 
                  className={`p-3 sm:p-4 cursor-pointer ${colors.bg} ${isExpanded ? '' : colors.hoverBg }`} // Evitar hoverBg si está expandido para que no interfiera con el color de fondo de la tarjeta expandida
                  onClick={() => handleToggleExpand(campaign.id)}
                  role="button"
                  tabIndex={0}
                  aria-expanded={isExpanded}
                  aria-controls={`campaign-details-${campaign.id}`}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleToggleExpand(campaign.id); }}
                >
                  <div className="flex justify-between items-start mb-1 sm:mb-2 gap-2">
                    <h4 className={`text-base sm:text-lg font-semibold ${colors.nameText} break-words flex-1 min-w-0`}>{campaign.name}</h4>
                    <span className={`text-xs sm:text-sm ${colors.dateText} whitespace-nowrap flex-shrink-0`}>
                      {formatDate(campaign.startDate, summaryDateOptions)} - {formatDate(campaign.endDate, summaryDateOptions)}
                    </span>
                  </div>
                  <div className={`w-full ${colors.progressTrack} rounded-full h-2 sm:h-2.5`} title={`${Math.round(progressPercentage)}% completado (${completedTasks}/${totalTasks} tareas)`}>
                    <div 
                      className={`${colors.progressFill} h-full rounded-full transition-all duration-500 ease-out`} 
                      style={{ width: `${progressPercentage}%` }}
                      aria-valuenow={progressPercentage}
                      aria-valuemin={0}
                      aria-valuemax={100}
                    ></div>
                  </div>
                  {totalTasks === 0 && <p className="text-xs text-gray-400 italic mt-1">Sin tareas asignadas.</p>}
                </div>

                {isExpanded && (
                  <div id={`campaign-details-${campaign.id}`} className="border-t border-gray-200 bg-white"> {/* Asegura que el fondo de la tarjeta expandida sea blanco */}
                    <CampaignCard 
                      campaign={campaign} 
                      onUpdateStatus={onUpdateStatus}
                      onToggleTask={onToggleTask}
                      onDeleteCampaign={onDeleteCampaign}
                      onAddTask={onAddTask}
                      onEditCampaign={onEditCampaign}
                      onDuplicateCampaign={onDuplicateCampaign}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default CampaignList;
