
import React from 'react';
import { PlusIcon } from './icons/PlusIcon';

interface HeaderProps {
  onAddCampaignClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onAddCampaignClick }) => {
  return (
    <header className="bg-white shadow-md p-4 sm:p-6 mb-6 rounded-lg">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl sm:text-3xl font-bold text-primary-dark">
          Gestor de Campañas
        </h1>
        <button
          onClick={onAddCampaignClick}
          className="bg-primary hover:bg-primary-dark text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition duration-150 ease-in-out flex items-center space-x-2"
        >
          <PlusIcon className="w-5 h-5" />
          <span>Añadir Campaña</span>
        </button>
      </div>
    </header>
  );
};

export default Header;
