import React, { useState } from 'react';
import { Campaign, CampaignStatus, Task, CampaignType } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';
import { PencilIcon } from './icons/PencilIcon';
import { DuplicateIcon } from './icons/DuplicateIcon';
import { getStatusIcon, getStatusColor } from './icons/StatusIcons';
import { formatDate } from '../utils';

interface CampaignCardProps {
  campaign: Campaign;
  onUpdateStatus: (campaignId: string, status: CampaignStatus) => void;
  onToggleTask: (campaignId: string, taskId: string) => void;
  onDeleteCampaign: (campaignId: string) => void;
  onAddTask: (campaignId: string, taskDescription: string) => void;
  onEditCampaign: (campaignId: string) => void;
  onDuplicateCampaign: (campaignId: string) => void;
}

const CampaignCard: React.FC<CampaignCardProps> = ({ campaign, onUpdateStatus, onToggleTask, onDeleteCampaign, onAddTask, onEditCampaign, onDuplicateCampaign }) => {
  const [newTaskDescription, setNewTaskDescription] = useState('');

  const completedTasks = campaign.tasks.filter(task => task.completed).length;
  const totalTasks = campaign.tasks.length;
  const progressPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  const handleAddNewTask = () => {
    if (newTaskDescription.trim()) {
      onAddTask(campaign.id, newTaskDescription.trim());
      setNewTaskDescription('');
    }
  };

  const getTypeSpecificProgressColors = (type: CampaignType) => {
    if (type === CampaignType.NATIONAL) {
      return {
        progressTrack: 'bg-purple-200',
        progressFill: 'bg-purple-600',
      };
    }
    // CampaignType.LOCAL
    return {
      progressTrack: 'bg-teal-200',
      progressFill: 'bg-teal-600',
    };
  };
  const progressColors = getTypeSpecificProgressColors(campaign.type);

  const statusOrder: CampaignStatus[] = [
    CampaignStatus.NOT_STARTED,
    CampaignStatus.IN_PROGRESS,
    CampaignStatus.FINISHED,
  ];

  const handleChangeStatus = () => {
    const currentIndex = statusOrder.indexOf(campaign.status);
    const nextIndex = (currentIndex + 1) % statusOrder.length;
    const nextStatus = statusOrder[nextIndex];
    onUpdateStatus(campaign.id, nextStatus);
  };

  return (
    <div className="bg-white rounded-b-xl p-5">
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1 min-w-0 pr-2">
          <h3 className="text-xl font-semibold text-gray-800 break-words">{campaign.name}</h3>
          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${campaign.type === CampaignType.NATIONAL ? 'bg-purple-200 text-purple-700' : 'bg-teal-200 text-teal-700'}`}>
            {campaign.type}
          </span>
        </div>
        <div className="flex space-x-1 flex-shrink-0">
           <button 
            onClick={() => onEditCampaign(campaign.id)} 
            className="text-gray-400 hover:text-blue-600 p-1 rounded-full hover:bg-blue-100 transition-colors"
            aria-label={`Editar campaña ${campaign.name}`}
            title="Editar Campaña"
            >
            <PencilIcon className="w-5 h-5" />
          </button>
          <button 
            onClick={() => onDuplicateCampaign(campaign.id)}
            className="text-gray-400 hover:text-indigo-600 p-1 rounded-full hover:bg-indigo-100 transition-colors"
            aria-label={`Duplicar campaña ${campaign.name}`}
            title="Duplicar Campaña"
            >
            <DuplicateIcon className="w-5 h-5" />
          </button>
          <button 
            onClick={() => onDeleteCampaign(campaign.id)} 
            className="text-gray-400 hover:text-danger p-1 rounded-full hover:bg-red-100 transition-colors"
            aria-label={`Eliminar campaña ${campaign.name}`}
            title="Eliminar Campaña"
            >
            <TrashIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div 
        className="mb-3 inline-block"
        role="button"
        tabIndex={0}
        onClick={handleChangeStatus}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleChangeStatus(); }}
        aria-label={`Cambiar estado de la campaña. Estado actual: ${campaign.status}. Haz clic para cambiar.`}
        title={`Estado actual: ${campaign.status}. Haz clic para cambiar.`}
      >
        <span className={`inline-flex items-center gap-2 text-sm font-medium px-3 py-1 rounded-full cursor-pointer transition-all hover:brightness-95 active:brightness-90 ${getStatusColor(campaign.status)}`}>
          {getStatusIcon(campaign.status)}
          {campaign.status}
        </span>
      </div>
      
      <div className="text-sm text-gray-600 mb-3 space-y-1">
        <p><strong>Inicio:</strong> {formatDate(campaign.startDate)}</p>
        <p><strong>Fin:</strong> {formatDate(campaign.endDate)}</p>
        {campaign.url && (
          <p className="min-w-0">
            <strong>URL:</strong>{' '}
            <a 
              href={campaign.url.startsWith('http') ? campaign.url : `http://${campaign.url}`} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-primary hover:text-primary-dark underline break-all"
            >
              {campaign.url}
            </a>
          </p>
        )}
      </div>

      <div className="mb-1 flex-grow flex flex-col min-h-[100px]">
        <h4 className="text-md font-semibold text-gray-700 mb-2">Tareas ({completedTasks}/{totalTasks}):</h4>
        {totalTasks > 0 && (
          <div className={`w-full ${progressColors.progressTrack} rounded-full h-2.5 mb-2 flex-shrink-0`} title={`${Math.round(progressPercentage)}% completado`}>
            <div className={`${progressColors.progressFill} h-2.5 rounded-full`} style={{ width: `${progressPercentage}%` }} aria-valuenow={progressPercentage} aria-valuemin={0} aria-valuemax={100}></div>
          </div>
        )}
        <ul className="space-y-1.5 max-h-32 overflow-y-auto pr-1 mb-2 flex-grow">
          {campaign.tasks.length > 0 ? campaign.tasks.map(task => (
            <li key={task.id} className="flex items-start">
              <input 
                type="checkbox" 
                id={`task-${campaign.id}-${task.id}`} 
                checked={task.completed} 
                onChange={() => onToggleTask(campaign.id, task.id)}
                className="w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded focus:ring-primary focus:ring-2 mr-2 mt-0.5 flex-shrink-0"
              />
              <label htmlFor={`task-${campaign.id}-${task.id}`} className={`text-sm ${task.completed ? 'line-through text-gray-500' : 'text-gray-700'} break-words min-w-0`}>
                {task.description}
              </label>
            </li>
          )) : <p className="text-sm text-gray-500 italic">No hay tareas asignadas.</p>}
        </ul>
      </div>
      
      <div className="mt-2 mb-4 flex-shrink-0">
        <div className="flex items-center space-x-2">
          <input 
            type="text"
            value={newTaskDescription}
            onChange={(e) => setNewTaskDescription(e.target.value)}
            placeholder="Añadir nueva tarea..."
            className="flex-grow px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-sm min-w-0"
            aria-label={`Nueva tarea para ${campaign.name}`}
          />
          <button 
            onClick={handleAddNewTask} 
            className="p-2 bg-primary hover:bg-primary-dark text-white rounded-md flex-shrink-0"
            aria-label={`Añadir nueva tarea a ${campaign.name}`}
            title="Añadir Tarea"
            >
            <PlusIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* El selector de estado <select> ha sido eliminado. El cambio de estado se realiza haciendo clic en la etiqueta de estado de arriba. */}
    </div>
  );
};

export default CampaignCard;