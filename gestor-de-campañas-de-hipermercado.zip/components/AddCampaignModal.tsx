import React, { useState, useEffect } from 'react';
import { Campaign, CampaignType } from '../types';

export interface CampaignFormData {
  name: string;
  type: CampaignType;
  startDate: string;
  endDate: string;
  url?: string;
}

interface AddEditCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (campaignData: CampaignFormData, campaignId?: string) => void;
  campaignToEdit?: Campaign | null;
}

const AddEditCampaignModal: React.FC<AddEditCampaignModalProps> = ({ isOpen, onClose, onSave, campaignToEdit }) => {
  const [name, setName] = useState('');
  const [type, setType] = useState<CampaignType>(CampaignType.NATIONAL);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [url, setUrl] = useState('');
  const [error, setError] = useState<string | null>(null);

  const isEditing = !!campaignToEdit;

  useEffect(() => {
    if (isEditing && campaignToEdit) {
      setName(campaignToEdit.name);
      setType(campaignToEdit.type);
      setStartDate(campaignToEdit.startDate);
      setEndDate(campaignToEdit.endDate);
      setUrl(campaignToEdit.url || '');
    } else {
      resetForm();
    }
  }, [isOpen, campaignToEdit, isEditing]);

  const resetForm = () => {
    setName('');
    setType(CampaignType.NATIONAL);
    setStartDate('');
    setEndDate('');
    setUrl('');
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !startDate || !endDate) {
      setError("Nombre, fecha de inicio y fecha de fin son obligatorios.");
      return;
    }
    if (new Date(startDate) > new Date(endDate)) {
        setError("La fecha de inicio no puede ser posterior a la fecha de fin.");
        return;
    }
    if (url && !url.match(/^(https?:\/\/)?([\w.-]+)\.([a-z]{2,})(\/[\w.-]*)*\/?(\?[\w%.-]+=[\w%.-]+(&[\w%.-]+=[\w%.-]+)*)?(#\w*)?$/i)) {
      setError("Por favor, introduce una URL válida (ej. http://example.com) o deja el campo vacío.");
      return;
    }


    onSave({ name, type, startDate, endDate, url: url.trim() || undefined }, campaignToEdit?.id);
    if (!isEditing) { // Solo resetear si es añadir, para no perder datos al cerrar modal de edición.
        resetForm();
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 transition-opacity duration-300 ease-in-out">
      <div className="bg-white p-6 sm:p-8 rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">
          {isEditing ? 'Editar Campaña' : 'Añadir Nueva Campaña'}
        </h2>
        {error && <p className="text-red-500 bg-red-100 p-3 rounded-md mb-4">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Nombre de la Campaña</label>
            <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required 
                   className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"/>
          </div>
          <div>
            <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-1">Tipo de Campaña</label>
            <select id="type" value={type} onChange={(e) => setType(e.target.value as CampaignType)}
                    disabled={isEditing}
                    className={`w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary bg-white ${isEditing ? 'bg-gray-100 cursor-not-allowed' : ''}`}>
              {Object.values(CampaignType).map(value => <option key={value} value={value}>{value}</option>)}
            </select>
             {isEditing && <p className="text-xs text-gray-500 mt-1">El tipo de campaña no se puede cambiar después de la creación.</p>}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">Fecha de Inicio</label>
              <input type="date" id="startDate" value={startDate} onChange={(e) => setStartDate(e.target.value)} required
                     className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"/>
            </div>
            <div>
              <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">Fecha de Fin</label>
              <input type="date" id="endDate" value={endDate} onChange={(e) => setEndDate(e.target.value)} required
                     className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"/>
            </div>
          </div>
          <div>
            <label htmlFor="url" className="block text-sm font-medium text-gray-700 mb-1">URL de la Campaña (Opcional)</label>
            <input type="url" id="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://ejemplo.com/campana"
                   className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"/>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <button type="button" onClick={() => { if (!isEditing) resetForm(); onClose(); }} 
                    className="px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-md font-medium transition duration-150">
              Cancelar
            </button>
            <button type="submit" 
                    className="px-4 py-2 bg-primary hover:bg-primary-dark text-white font-medium rounded-md shadow-sm transition duration-150">
              {isEditing ? 'Guardar Cambios' : 'Guardar Campaña'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEditCampaignModal;